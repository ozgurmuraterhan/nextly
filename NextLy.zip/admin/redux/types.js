export const SWITCH_LANGUAGE = 'SWITCH-LANGUAGE';
//Login
export const SET_LOGIN = 'SET_LOGIN';
export const SET_ISAUTHENTICATED = 'SET_ISAUTHENTICATED';
export const SET_LOGOUT = 'SET_LOGOUT';

export const CHANGE_COLLAPSED = 'CHANGE_COLLAPSED';


// Customize const







