import enLang from "./entries/en-US";
import tRLang from "./entries/tr-TR";


const AppLocale = {
  en: enLang,
  tr: tRLang,
};

export default AppLocale;
