import React from 'react';
import Dashboard from "./dashboard";

const homePage = () => {

  return <Dashboard />;
}

export default homePage;
