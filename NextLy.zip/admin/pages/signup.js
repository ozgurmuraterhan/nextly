import React from 'react';
import asyncComponent from "../util/asyncComponent";

import IntlMessages from "../util/IntlMessages";

const SignUpPage = () => {
  return <div>  <IntlMessages id="app.userAuth.signIn" />  </div>;
}

export default SignUpPage;
