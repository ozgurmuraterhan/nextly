import React from 'react';
import asyncComponent from "../util/asyncComponent";


const SignUpPage = () => {
  return <div>sign up</div>;
}

export default SignUpPage;
