# nextly
nextly ecommerce

please updated config.js file and please updated backend/.env file 

1-) npm run allnpmi
2-) npm run allnpmbuild
3-) npm run allnpmstart

