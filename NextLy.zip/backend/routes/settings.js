const router = require("express").Router();
const passport = require("passport");
let Settings = require("../models/settings.model");
let Users = require("../models/users.model");

const title = "Settings";

// get all items
router.route("/").get(passport.authenticate("jwt", { session: false }), (req, res, next) => {

   const rolesControl = req.user.role;
   if (rolesControl["superadmin"]) {
      Settings.find()
         .then((data) => {
            res.json(data);
         })
         .catch((err) =>
            res.json({
               messagge: "Error: " + err,
               variant: "error",
            })
         );
   } else {
      res.status(403).json({
         message: {
            messagge: "You are not authorized, go away!",
            variant: "error",
         },
      });
   }
});

// fetch data by id
router.route("/:id").get(passport.authenticate("jwt", { session: false }), (req, res, next) => {

   const rolesControl = req.user.role;
   if (rolesControl["superadmin"]) {
      Settings.findById(req.params.id)
         .then((data) => res.json(data))
         .catch((err) =>
            res.status(400).json({
               messagge: "Error: " + err,
               variant: "error",
            })
         );
   } else {
      res.status(403).json({
         message: {
            messagge: "You are not authorized, go away!",
            variant: "error",
         },
      });
   }
});

// update data by id
router.route("/:id").post(passport.authenticate("jwt", { session: false }), (req, res, next) => {

   const rolesControl = req.user.role;
   if (rolesControl["superadmin"]) {
      Settings.findByIdAndUpdate(req.params.id, req.body)
         .then(() =>
            res.json({
               messagge: title + " Update",
               variant: "success",
            })
         )
         .catch((err) =>
            res.json({
               messagge: "Error: " + err,
               variant: "error",
            })
         );
   } else {
      res.status(403).json({
         message: {
            messagge: "You are not authorized, go away!",
            variant: "error",
         },
      });
   }
});

module.exports = router;
